package com.last.springboot.springbootlogical;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootLogicalApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootLogicalApplication.class, args);
	}

}
