package com.last.springboot.springbootlogical;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootLogicalApplicationTests {

	@Test
	void contextLoads() {
	}

}
