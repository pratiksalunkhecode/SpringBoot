package com.javamasterlastpractice.MyTodoApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyTodoAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
