package com.in28minute.learnJpaandHibernatefinal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LearnJpaAndHibernateFinalApplication {

	public static void main(String[] args) {
		SpringApplication.run(LearnJpaAndHibernateFinalApplication.class, args);
	}

}
