package com.in28minute.learnJpaandHibernatefinal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearnJpaAndHibernateFinalApplicationTests {

	@Test
	void contextLoads() {
	}

}
